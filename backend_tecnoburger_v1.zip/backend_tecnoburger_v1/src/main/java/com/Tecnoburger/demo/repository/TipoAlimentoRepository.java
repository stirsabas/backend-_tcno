package com.Tecnoburger.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.Tecnoburger.demo.Modelo.TipoAlimento;

@Repository
public interface TipoAlimentoRepository extends JpaRepository <TipoAlimento, Integer>{
    
    @Query(value="select * from tipoalimento where id = :codigo", nativeQuery = true)
    public TipoAlimento BuscarPorId(@Param("codigo") Integer codigoTipoA);
}
