package com.Tecnoburger.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.Tecnoburger.demo.Modelo.Usuario;
import com.Tecnoburger.demo.service.UsuarioService;

@RestController
@RequestMapping("/usuarios")
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

    // registrar usuario
    @PostMapping("/registrar")
    public int save(@RequestBody Usuario usuario) throws Exception {

        if (usuario.getEmail() == "" || usuario.getPassword() == "") {
            throw new Exception("El correo o la contraseña no deben estar vacio");
        } else {
            usuarioService.save(usuario);
            
            System.out.println("Usuario registrado con exito");
        }
        return 1;
    }

    

    // Consultar todos los usuarios
    @GetMapping("/consultar")
    public List<Usuario> consultar() {
        return usuarioService.consultar();
    }
}
