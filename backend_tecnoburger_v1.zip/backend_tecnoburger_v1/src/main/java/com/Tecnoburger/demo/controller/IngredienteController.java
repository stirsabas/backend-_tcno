package com.Tecnoburger.demo.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.Tecnoburger.demo.Modelo.Ingrediente;
import com.Tecnoburger.demo.service.IngredienteService;

@RestController
@RequestMapping("/ingrediente")
public class IngredienteController {

    @Autowired
    private IngredienteService ingredienteService;

    // crear alimento
    @PostMapping("/crear")
    public Ingrediente save(@RequestBody Ingrediente ingrediente) {

        return ingredienteService.save(ingrediente);
    }

    // consultar alimento
    @GetMapping("/consultar")
    public List<Ingrediente> consultar() {

        return ingredienteService.consultar();
    }

    // buscar alimento por id
    @GetMapping("/buscar/{code}")
    public List<Ingrediente> buscarPorId(@PathVariable Integer code) {
        return ingredienteService.buscarPorId(code);
    }

}
