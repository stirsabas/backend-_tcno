package com.Tecnoburger.demo.controller;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.Tecnoburger.demo.Modelo.Alimento;
import com.Tecnoburger.demo.service.AlimentoService;

@RestController
@RequestMapping("/alimento")
public class AlimentoController {

    @Autowired
    private AlimentoService alimentoService;

    // crear alimento
    
    @PostMapping("/crear")
    public Alimento save(@RequestBody Alimento alimento) {
        return alimentoService.save(alimento);
    }

    // Consultar todos los alimentos
    @GetMapping("/consultar")
    public List<Alimento> consultar() {
        return alimentoService.consultar();
    }

    // Consultar alimento por id
    @GetMapping("/buscar/{code}")
    public List<Alimento> alimentosPorId(@PathVariable Integer code) {
        return alimentoService.buscarPorId(code);
    }

}
