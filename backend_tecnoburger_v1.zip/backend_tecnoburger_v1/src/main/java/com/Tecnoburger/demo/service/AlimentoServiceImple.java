package com.Tecnoburger.demo.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.Tecnoburger.demo.Modelo.Alimento;
import com.Tecnoburger.demo.repository.AlimentoRepository;

@Service
public class AlimentoServiceImple implements AlimentoService{
    
    @Autowired
    public  AlimentoRepository alimentoRepository;
        

	
    @Transactional
    @Override
    public Alimento save(Alimento alimento){
        return alimentoRepository.save(alimento);
    }

    @Override
    public List<Alimento> consultar(){
        return alimentoRepository.findAll();
    }

    @Override
    public List<Alimento> buscarPorId(Integer codigo) {
        
        return alimentoRepository.BuscarPorId(codigo);
    }

}