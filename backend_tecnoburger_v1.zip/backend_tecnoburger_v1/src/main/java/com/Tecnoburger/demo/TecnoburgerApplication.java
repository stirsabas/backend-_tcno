package com.Tecnoburger.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TecnoburgerApplication {

	public static void main(String[] args) {
		SpringApplication.run(TecnoburgerApplication.class, args);
	}

}
