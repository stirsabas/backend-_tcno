package com.Tecnoburger.demo.Modelo;

import lombok.*;
import java.util.List;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonManagedReference;


@AllArgsConstructor
@NoArgsConstructor
@Entity
public class TipoAlimento {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer tipoAlimentoId;
    private String nombre;
    private String logotipo;
    @OneToMany(cascade = CascadeType.ALL , mappedBy = "tipoAlimento",  fetch = FetchType.LAZY)
    private List <Alimento> alimentos;


    public Integer getTipoAlimentoId() {
        return tipoAlimentoId;
    }

    public void setTipoAlimentoId(Integer tipoAlimentoId) {
        this.tipoAlimentoId = tipoAlimentoId;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getLogotipo() {
        return logotipo;
    }

    public void setLogotipo(String logotipo) {
        this.logotipo = logotipo;
    }

    @JsonManagedReference
    public List<Alimento> getAlimentos() {
        return alimentos;
    }

    public void setAlimentos(List<Alimento> alimentos) {
        this.alimentos = alimentos;
    }

}
