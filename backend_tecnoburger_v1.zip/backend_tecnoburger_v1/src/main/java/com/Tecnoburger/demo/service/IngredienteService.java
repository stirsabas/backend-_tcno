package com.Tecnoburger.demo.service;

import java.util.List;

import com.Tecnoburger.demo.Modelo.Ingrediente;

public interface IngredienteService {
    Ingrediente save (Ingrediente ingrediente);
    List <Ingrediente> consultar();
    List<Ingrediente> buscarPorId(Integer codigo);
}
