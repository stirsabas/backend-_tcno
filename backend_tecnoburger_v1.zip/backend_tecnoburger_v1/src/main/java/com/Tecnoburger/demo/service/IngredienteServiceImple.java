package com.Tecnoburger.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Tecnoburger.demo.Modelo.Ingrediente;
import com.Tecnoburger.demo.repository.IngredienteRepository;

@Service
public class IngredienteServiceImple implements IngredienteService {

    @Autowired
    private IngredienteRepository ingredienteRepository;

    // crear ingrediente
    @Override
    public Ingrediente save(Ingrediente ingrediente) {
        return ingredienteRepository.save(ingrediente);
    }

    // listar ingrediente
    @Override
    public List<Ingrediente> consultar() {
        return ingredienteRepository.findAll();
    }

    @Override
    public List<Ingrediente> buscarPorId(Integer codigo) {

        return ingredienteRepository.BuscarPorId(codigo);
    }

}
