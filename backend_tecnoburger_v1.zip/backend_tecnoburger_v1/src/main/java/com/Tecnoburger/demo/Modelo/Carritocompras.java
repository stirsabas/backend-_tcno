package com.Tecnoburger.demo.Modelo;

import javax.persistence.*;

@Entity
@Table(name ="carritocompras")
public class Carritocompras {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private Integer fecha;







    Carritocompras(){}
    public Carritocompras(Integer id, Integer fecha) {
        this.id = id;
        this.fecha = fecha;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getFecha() {
        return fecha;
    }

    public void setFecha(Integer fecha) {
        this.fecha = fecha;
    }
}
