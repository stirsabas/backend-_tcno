package com.Tecnoburger.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Tecnoburger.demo.Modelo.TipoAlimento;
import com.Tecnoburger.demo.repository.TipoAlimentoRepository;

@Service
public class TipoAlimentoServiceImple implements TipoAlimentoService {
    
    @Autowired
    private  TipoAlimentoRepository alimentoRepository;
        

	//crear tipoalimento
    @Override
    public TipoAlimento save(TipoAlimento tipoAlimento){
        return alimentoRepository.save(tipoAlimento);
    }

    @Override
    public List<TipoAlimento> consultar(){
        return alimentoRepository.findAll();
    }

    @Override
    public TipoAlimento buscarPorId(Integer codigo) {        
        return alimentoRepository.BuscarPorId(codigo);
    }
}
