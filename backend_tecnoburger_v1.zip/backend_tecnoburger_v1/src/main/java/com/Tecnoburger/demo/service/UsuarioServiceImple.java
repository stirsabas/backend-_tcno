package com.Tecnoburger.demo.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.Tecnoburger.demo.Modelo.Usuario;
import com.Tecnoburger.demo.repository.UsuarioRepository;

@Service
public class UsuarioServiceImple implements UsuarioService{
    
    @Autowired
    private  UsuarioRepository usuarioRepository;
        

	//crear usuario
    @Override
    public Usuario save(Usuario usuario){
        return usuarioRepository.save(usuario);
    }

    @Override
    public List<Usuario> consultar(){
        return usuarioRepository.findAll();
    }
    

}
