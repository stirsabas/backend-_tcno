package com.Tecnoburger.demo.service;

import java.util.List;

import com.Tecnoburger.demo.Modelo.TipoIngrediente;

public interface TipoIngredienteService {
    TipoIngrediente save (TipoIngrediente tipoIngrediente);
    List <TipoIngrediente> consultar();
    List<TipoIngrediente> buscarPorId(Integer codigo);
}