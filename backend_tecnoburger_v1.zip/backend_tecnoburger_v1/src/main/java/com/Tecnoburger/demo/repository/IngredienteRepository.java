package com.Tecnoburger.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.Tecnoburger.demo.Modelo.Ingrediente;

@Repository
public interface IngredienteRepository extends JpaRepository<Ingrediente, Integer>{
    
    @Query(value="select * from ingrediente where id = :codigo", nativeQuery = true)
    public List<Ingrediente> BuscarPorId(@Param("codigo") Integer codigoIngrediente);
}
