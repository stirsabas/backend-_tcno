package com.Tecnoburger.demo.service;

import java.util.List;

import com.Tecnoburger.demo.Modelo.TipoAlimento;

public interface TipoAlimentoService {
    TipoAlimento save (TipoAlimento tipoAlimento);
    List <TipoAlimento> consultar();
    TipoAlimento buscarPorId(Integer codigo);
}
