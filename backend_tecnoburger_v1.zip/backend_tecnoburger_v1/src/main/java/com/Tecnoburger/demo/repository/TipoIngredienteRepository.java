package com.Tecnoburger.demo.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.Tecnoburger.demo.Modelo.TipoIngrediente;

@Repository
public interface TipoIngredienteRepository extends JpaRepository<TipoIngrediente, Integer> {

    @Query(value = "select * from tipoingrediente where id = :codigo", nativeQuery = true)
    public List<TipoIngrediente> BuscarPorId(@Param("codigo") Integer codigo);
}
