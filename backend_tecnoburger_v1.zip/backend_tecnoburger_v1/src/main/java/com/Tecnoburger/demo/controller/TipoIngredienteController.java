package com.Tecnoburger.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.Tecnoburger.demo.Modelo.TipoIngrediente;
import com.Tecnoburger.demo.service.TipoIngredienteService;

@RestController
@RequestMapping("/tipoIngrediente")
public class TipoIngredienteController {

    @Autowired
    private TipoIngredienteService tipoIngredienteService;

    // registrar tipo de ingrediente
    @PostMapping("/registrar")
    public TipoIngrediente save(@RequestBody TipoIngrediente tipoIngrediente) {

        return tipoIngredienteService.save(tipoIngrediente);
    }

    // consultar todos los tipos de ingrdientes
    @GetMapping("/consultar")
    public List<TipoIngrediente> consultar() {
        return tipoIngredienteService.consultar();
    }

    // buscar tipo de ingrediente por id
    @GetMapping("/buscar/{code}")
    public List<TipoIngrediente> buscarPorId(@PathVariable Integer code) {
        return tipoIngredienteService.buscarPorId(code);
    }
}
