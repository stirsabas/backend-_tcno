package com.Tecnoburger.demo.service;

import java.util.List;

import com.Tecnoburger.demo.Modelo.Usuario;


public interface UsuarioService {
    Usuario save (Usuario usuario);
    List <Usuario> consultar();
    
}
