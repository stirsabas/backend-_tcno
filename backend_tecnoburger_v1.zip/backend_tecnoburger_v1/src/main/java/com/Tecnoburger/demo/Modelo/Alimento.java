package com.Tecnoburger.demo.Modelo;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import lombok.*;

import java.io.Serializable;
import java.util.*;

@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Alimento implements Serializable{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer AlimentoId;
    private String nombre;
    private Double precio;
    private String imagen;
    @ManyToOne
    @JoinColumn(name = "tipoAlimento_id")
    private TipoAlimento tipoAlimento;

    @OneToMany(cascade = CascadeType.ALL , mappedBy = "alimento",  fetch = FetchType.LAZY)
    private List<Ingrediente> ingredientes;


    public Integer getAlimentoId() {
        return AlimentoId;
    }

    public void setAlimentoId(Integer alimentoId) {
        AlimentoId = alimentoId;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    @JsonBackReference
    public TipoAlimento getTipoAlimento() {
        return tipoAlimento;
    }

    public void setTipoAlimento(TipoAlimento tipoAlimento) {
        this.tipoAlimento = tipoAlimento;
    }

    public List<Ingrediente> getIngredientes() {
        return ingredientes;
    }

    public void setIngredientes(List<Ingrediente> ingredientes) {
        this.ingredientes = ingredientes;
    }

    

}
