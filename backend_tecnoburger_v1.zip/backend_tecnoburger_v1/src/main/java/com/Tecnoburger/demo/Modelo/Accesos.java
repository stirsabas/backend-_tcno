package com.Tecnoburger.demo.Modelo;


import javax.persistence.*;

@Entity
@Table(name ="accesos")
public class Accesos {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String nombre;
    private String path;
    private String icon;

    @ManyToOne
    @JoinColumn(name = "rol_id", nullable = false, foreignKey=@ForeignKey(name="FK_ROL_ID"))
    private Roles roles;
    Accesos(){}


    public Accesos(Integer id, String nombre, String path, String icon) {
        this.id = id;
        this.nombre = nombre;
        this.path = path;
        this.icon = icon;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }
}
