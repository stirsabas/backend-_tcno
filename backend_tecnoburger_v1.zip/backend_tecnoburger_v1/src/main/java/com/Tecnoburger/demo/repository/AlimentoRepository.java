package com.Tecnoburger.demo.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.Tecnoburger.demo.Modelo.Alimento;

@Repository
public interface AlimentoRepository extends JpaRepository<Alimento, Integer>{

    @Query(value="select * from alimento where id = :codigo", nativeQuery = true)
    public List<Alimento> BuscarPorId(@Param("codigo") Integer codigoUsuario);
}

