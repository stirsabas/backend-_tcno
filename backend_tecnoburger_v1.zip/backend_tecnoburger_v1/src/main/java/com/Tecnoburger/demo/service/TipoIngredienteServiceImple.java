package com.Tecnoburger.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Tecnoburger.demo.Modelo.TipoIngrediente;
import com.Tecnoburger.demo.repository.TipoIngredienteRepository;

@Service
public class TipoIngredienteServiceImple implements TipoIngredienteService {

    @Autowired
    private TipoIngredienteRepository tipoIngredienteRepository;

    // crear tipoIngrediente
    @Override
    public TipoIngrediente save(TipoIngrediente tipoAlimento) {
        return tipoIngredienteRepository.save(tipoAlimento);
    }

    @Override
    public List<TipoIngrediente> consultar() {
        return tipoIngredienteRepository.findAll();
    }

    @Override
    public List<TipoIngrediente> buscarPorId(Integer codigo) {
        return tipoIngredienteRepository.BuscarPorId(codigo);
    }
}