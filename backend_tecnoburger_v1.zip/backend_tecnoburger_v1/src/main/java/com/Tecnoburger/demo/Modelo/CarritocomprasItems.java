package com.Tecnoburger.demo.Modelo;

import javax.persistence.*;

@Entity
@Table(name ="carito_copras_items")

public class CarritocomprasItems {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private int cantidad;

    @OneToOne
    private TipoAlimento tipoAlimento;
    @ManyToOne
    @JoinColumn( name = "carritocompras_id", nullable = false, foreignKey=@ForeignKey(name="FK_CARRITOCOMPRAS_ID"))
    private Carritocompras carritocompras;




      CarritocomprasItems(){}

    public CarritocomprasItems(Integer id, int cantidad, TipoAlimento tipoAlimento, Carritocompras carritocompras) {
        this.id = id;
        this.cantidad = cantidad;
        this.tipoAlimento = tipoAlimento;
        this.carritocompras = carritocompras;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public TipoAlimento getTipoAlimento() {
        return tipoAlimento;
    }

    public void setTipoAlimento(TipoAlimento tipoAlimento) {
        this.tipoAlimento = tipoAlimento;
    }

    public Carritocompras getCarritocompras() {
        return carritocompras;
    }

    public void setCarritocompras(Carritocompras carritocompras) {
        this.carritocompras = carritocompras;
    }
}
