package com.Tecnoburger.demo.Modelo;


import javax.persistence.*;

@Entity
@Table(name ="roles")
public class Roles {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String tipo;
    private String descripcion;

    @OneToOne
    @JoinColumn(name = "usuario_id", nullable = false, foreignKey=@ForeignKey(name="FK_USUARIO_ID"))
    private Usuario usuario;
    Roles(){}

    public Roles(Integer id, String tipo, String descripcion) {
        this.id = id;
        this.tipo = tipo;
        this.descripcion = descripcion;
    }


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}
