package com.Tecnoburger.demo.service;

import java.util.List;
import com.Tecnoburger.demo.Modelo.Alimento;

public interface AlimentoService {
    Alimento save (Alimento alimento);
    List <Alimento> consultar();
    List<Alimento> buscarPorId(Integer codigo);
}