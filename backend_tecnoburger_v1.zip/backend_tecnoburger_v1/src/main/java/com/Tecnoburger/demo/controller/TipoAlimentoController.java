package com.Tecnoburger.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.Tecnoburger.demo.Modelo.TipoAlimento;
import com.Tecnoburger.demo.service.TipoAlimentoService;

@RestController
@RequestMapping("/tipoAlimento")
public class TipoAlimentoController {

    @Autowired
    private TipoAlimentoService tipoAlimentoService;

    // registrar el tipo de alimento
    @PostMapping(value ="/registrar")
    private TipoAlimento save(@RequestBody TipoAlimento tipoAlimento) {
        
        return tipoAlimentoService.save(tipoAlimento);
    }

    // consultar todos los tipos de alimentos
    @GetMapping("/consultar")
    private List<TipoAlimento> consultar() {
        return tipoAlimentoService.consultar();
    }

    // buscar tipo de alimento por id
    @GetMapping("/buscar/{code}")
    private TipoAlimento buscarPorId(@PathVariable Integer code) {
        return tipoAlimentoService.buscarPorId(code);
    }

    //Actualizar tipo alimento
    @PutMapping("/{code}")
    private TipoAlimento actualizar(@PathVariable Integer code, @RequestBody TipoAlimento tipoAlimento){
        tipoAlimento.setTipoAlimentoId(code);
        return tipoAlimentoService.save(tipoAlimento);
        
    }

}
